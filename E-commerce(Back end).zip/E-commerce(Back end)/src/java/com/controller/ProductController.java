/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.entities.Product;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.json.bind.annotation.JsonbTransient;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 *
 * @author ngounepeetprogress
 */
@Path("productcontroller")
public class ProductController {

    @GET
    @Path("/list")
    @Produces({"application/json"})
    public List<Product> listproduct() throws Exception {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("E-commercePU");
        EntityManager em = emf.createEntityManager();
        List<Product> products = Arrays.asList();
        TypedQuery<Product> queryProducts = em.createNamedQuery("Product.findAll", Product.class);

        try {
            products = queryProducts.getResultList();
        } catch (Exception e) {
            System.out.println("An error occured " + e.getMessage());
        }
        em.close();
        emf.close();
        return products;
        
    }
    @POST
    @Path("/addproduct")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces({"application/json"})
    public Product addProducts(Product product) {
       
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("E-commercePU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(product);
        em.getTransaction().commit(); 
        em.close();
        emf.close();
        return product;
    }
    @DELETE
    @Path("/delete/{productid}")
    @Produces({"application/json"})
    public Product deleteProduct(@PathParam("productid") int productid) throws Exception{
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("E-commercePU");
        EntityManager em =emf.createEntityManager();
        em.getTransaction().begin();
        Product product = em.find(Product.class, productid);
        em.remove(product);
        em.getTransaction().commit();
        em.close();
        emf.close();
        return product;
    }
    @GET
    @Path("/list/{name}")
    @Produces({"application/json"})
    public List<Product> listproductbyname (@PathParam("name") String name) throws Exception{
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("E-commercePU");
        EntityManager em = emf.createEntityManager();
        TypedQuery<Product> query = em.createNamedQuery("Product.findByName", Product.class);
        List<Product> products = query.setParameter("name",name).getResultList();
        em.close();
        emf.close();
        return products;
        
        
    }
    
}
