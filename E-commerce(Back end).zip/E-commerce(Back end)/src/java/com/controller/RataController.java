/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.entities.Rate;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

/**
 *
 * @author ngounepeetprogress
 */
@Path("/ratecontroller")
public class RataController {
    @GET
    @Path("/list")
    @Produces("application/json")
    public List<Rate> listrate() throws Exception{
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("E-commercePU");
        EntityManager em = emf.createEntityManager();
        TypedQuery<Rate> query = em.createNamedQuery("Rate.findAll", Rate.class);
        List<Rate> rates = query.getResultList();
        return rates;
    }
    @POST
    @Path("/add")
    @Produces("application/json")
    public Rate add(Rate rate) throws Exception{
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("E-commercePU");
        EntityManager  em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(rate);
        em.getTransaction().commit();
        return rate;
    }

}
