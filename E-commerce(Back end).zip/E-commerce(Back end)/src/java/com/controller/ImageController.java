/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.entities.Image;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

/**
 *
 * @author ngounepeetprogress
 */
@Path("/imagecontroller")
public class ImageController {
    @POST
    @Path("/addimage")
    @Produces({"application/json"})
    public Image addimage(Image image) throws Exception{
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("E-commercePU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(image);
        em.getTransaction().commit();
        em.close();
        emf.close();
        return image;
    }
    @GET
    @Path("/list")
    @Produces("application/json")
    public List<Image> list() throws Exception{
       EntityManagerFactory emf = Persistence.createEntityManagerFactory("E-commercePU");
       EntityManager em = emf.createEntityManager();
       TypedQuery<Image> query = em.createNamedQuery("Image.findAll", Image.class);
       List<Image> image = query.getResultList();
       em.close();
       emf.close();
        return image;
    }
    
}
