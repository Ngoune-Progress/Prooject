/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.entities.Category;
import java.util.Arrays;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

/**
 *
 * @author ngounepeetprogress
 */
@Path("/categorycontroller")
public class CategoryController {

    @POST
    @Path("/addcategory")
    @Produces({"application/json"})
    public Category addcategory(Category category) throws Exception {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("E-commercePU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(category);
        em.getTransaction().commit();
        em.close();
        emf.close();
        return category;

    }

    @GET
    @Path("/list")
    @Produces({"application/json"})
    public List<Category> list() throws Exception {
        List<Category> categories = Arrays.asList();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("E-commercePU");
        EntityManager em = emf.createEntityManager();
        TypedQuery<Category> query = em.createNamedQuery("Category.findAll", Category.class);
        categories = query.getResultList();

        return categories;
    }

    @GET
    @Path("/list/{name}")
    @Produces({"application/json"})
    public List<Category> categorybyname(@PathParam("name") String name) throws Exception {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("E-commercePU");
        EntityManager em = emf.createEntityManager();
        TypedQuery<Category> query = em.createNamedQuery("Category.findByName", Category.class);
        List<Category> category = query.setParameter("name", name).getResultList();
        em.close();
        emf.close();
        return category;

    }

    @DELETE
    @Path("/delete/{id}")
    @Produces({"application/json"})
    public Category deletecategory(@PathParam("id") int id) throws Exception {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("E-commercePU");
        EntityManager em = emf.createEntityManager();
        Category category = em.find(Category.class, id);
        em.getTransaction().begin();
        em.remove(category);
        em.getTransaction().commit();
        em.close();
        emf.close();
        return category;

    }
}
