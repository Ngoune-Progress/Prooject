/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.controller;

import com.entities.Customer;
import com.entities.Product;
import java.util.Arrays;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

/**
 *
 * @author ngounepeetprogress
 */
@Path("/customercontroller")
public class CustomerController {
    @POST
    @Path("/addcustomer")
    @Produces({"application/json"})
    public Customer addcustomer(Customer customer) throws Exception{
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("E-commercePU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(customer);
        em.getTransaction().commit(); 
        em.close();
        
        return customer;
    }
    
    @GET
    @Path("/list")
    @Produces({"application/json"})
    public List<Customer> list() throws Exception {
       List<Customer> customers =  Arrays.asList();
       EntityManagerFactory emf = Persistence.createEntityManagerFactory("E-commercePU");
       EntityManager em = emf.createEntityManager();
       try{
        TypedQuery<Customer> query = em.createNamedQuery("Customer.findAll",Customer.class);
        
            customers = query.getResultList();
        }catch(Exception e){
            System.out.println("An error occured "+e.getMessage());
        }
               em.close();
               emf.close();
        return customers;
        
       
    }
    @GET
    @Path("get/{login}")
    @Produces({"application/json"})
    public Customer find(@PathParam("login") String login) throws Exception{
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("E-commercePU");
        EntityManager em = emf.createEntityManager();
        TypedQuery<Customer> query = em.createNamedQuery("Customer.findByLogin", Customer.class);
        Customer customer = query.setParameter("login", login).getSingleResult();
        em.close();
        emf.close();
        return customer;
    }

    @PUT
    @Path("/updateuser/{userid}")
    @Produces({"application/json"})
    public Customer updateCustomer(@PathParam("userid") int  userid,Customer customer) throws Exception{
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("E-commercePU");
        EntityManager em= emf.createEntityManager();
       
       Customer c =  em.find(Customer.class, userid);
     em.getTransaction().begin();
        c.setLogin(customer.getLogin());
        c.setPassword(customer.getPassword());
        c.setShoppingcartCollection(customer.getShoppingcartCollection());
        c.setPaymentCollection(customer.getPaymentCollection());
        c.setPuchaseCollection(customer.getPuchaseCollection());
        c.setRateCollection(customer.getRateCollection());
        c.setCreditcardinfo(customer.getCreditcardinfo());
        c.setAddresse(customer.getAddresse());
        c.setStatus(customer.getStatus());
        em.getTransaction().commit();
        em.close();
        emf.close();
        return c;
               
    }
    @DELETE
    @Path("/delete/{userid}")
    @Produces({"application/json"})
    public Customer deletecustomer(@PathParam("userid")int userid)throws Exception{
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("E-commercePU");
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Customer customer = em.find(Customer.class, userid);
        em.remove(customer);
        em.getTransaction().commit();
        em.close();
        emf.close();
        return customer;
    }
    
}
