/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.entities;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author ngounepeetprogress
 */
@Entity
@Table(name = "puchase")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Puchase.findAll", query = "SELECT p FROM Puchase p"),
    @NamedQuery(name = "Puchase.findByPurchaseid", query = "SELECT p FROM Puchase p WHERE p.purchaseid = :purchaseid"),
    @NamedQuery(name = "Puchase.findByDatecreate", query = "SELECT p FROM Puchase p WHERE p.datecreate = :datecreate"),
    @NamedQuery(name = "Puchase.findByDateshipped", query = "SELECT p FROM Puchase p WHERE p.dateshipped = :dateshipped"),
    @NamedQuery(name = "Puchase.findByStatus", query = "SELECT p FROM Puchase p WHERE p.status = :status")})
public class Puchase implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "purchaseid")
    private Integer purchaseid;
    @Column(name = "datecreate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date datecreate;
    @Column(name = "dateshipped")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateshipped;
    @Size(max = 254)
    @Column(name = "status")
    private String status;
    @JoinColumn(name = "userid", referencedColumnName = "userid")
    @ManyToOne(optional = false)
    private Customer userid;

    public Puchase() {
    }

    public Puchase(Integer purchaseid) {
        this.purchaseid = purchaseid;
    }

    public Integer getPurchaseid() {
        return purchaseid;
    }

    public void setPurchaseid(Integer purchaseid) {
        this.purchaseid = purchaseid;
    }

    public Date getDatecreate() {
        return datecreate;
    }

    public void setDatecreate(Date datecreate) {
        this.datecreate = datecreate;
    }

    public Date getDateshipped() {
        return dateshipped;
    }

    public void setDateshipped(Date dateshipped) {
        this.dateshipped = dateshipped;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Customer getUserid() {
        return userid;
    }

    public void setUserid(Customer userid) {
        this.userid = userid;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (purchaseid != null ? purchaseid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Puchase)) {
            return false;
        }
        Puchase other = (Puchase) object;
        if ((this.purchaseid == null && other.purchaseid != null) || (this.purchaseid != null && !this.purchaseid.equals(other.purchaseid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.entities.Puchase[ purchaseid=" + purchaseid + " ]";
    }
    
}
